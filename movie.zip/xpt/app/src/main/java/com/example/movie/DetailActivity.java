package com.example.movie;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {

    public static final String DATA_FILM = "DATA_FILM" ;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView img= (ImageView) findViewById(R.id.imgFilm);
        TextView content= (TextView) findViewById(R.id.contentFilm);
        TextView title = (TextView) findViewById(R.id.titleFilm);


        Film film = getIntent().getParcelableExtra(DATA_FILM);

        int dataImg =  film.getImage();
        String dataContent = film.getContent();
        String dataTitle = film.getTitle();

        img.setImageResource(dataImg);
        content.setText(dataContent);
        title.setText(dataTitle);

    }
}
